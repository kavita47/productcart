package com.capgemini.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.capgemini.Exception.EmptyProductList;
import com.capgemini.Exception.InvalidProductException;
import com.capgemini.bean.Product;


@Repository("repo")
public class ProductRepositoryImp implements IProductRepository{
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Product addProduct(Product product) {
		entityManager.persist(product);
		entityManager.flush();
		return product;
	}

	@Override
	public Product findProduct(int id) {
		Product product= 
				entityManager.find(Product.class, id);
		if(product==null) {
			throw new InvalidProductException();
		}
			
			product.setId(id);
		return product;
	}
	

	@Override
	public Product updateProduct(Product product) {
		entityManager.merge(product);
		entityManager.flush();
		return product;
	}

	@Override
	public List<Product> getProductList() {
		
		TypedQuery<Product> query=
				entityManager.createQuery
				("select product from Product product ", Product.class);
				
						
					List<Product> list= query.getResultList();
					if(list==null)
					{
						throw new EmptyProductList();
					}
				return list;
	}

	@Override
	public Product removeProduct(int id) {
		Product product= entityManager.find(Product.class, id);
		if(product==null)
		{
			throw new InvalidProductException();
		}
		return product;
	}

}
