package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.Product;
import com.capgemini.repository.IProductRepository;
@Transactional
@Service("service")
public class ProductServiceImp implements IProductService {
	@Autowired
	IProductRepository repo;
	

	public IProductRepository getRepo() {
		return repo;
	}

	public void setRepo(IProductRepository repo) {
		this.repo = repo;
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return repo.addProduct(product);
	}

	@Override
	public Product findProduct(int id) {
		// TODO Auto-generated method stub
		return repo.findProduct(id);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return repo.updateProduct(product);
	}

	@Override
	public List<Product> getProductList() {
		// TODO Auto-generated method stub
		return repo.getProductList();
	}

	@Override
	public Product removeProduct(int id) {
		// TODO Auto-generated method stub
		return repo.removeProduct(id);
	}

}
