package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Product;



public interface IProductService {
	public Product addProduct(Product product);
	public Product findProduct(int id);
	public Product updateProduct(Product product);
	public List<Product> getProductList();
	public Product removeProduct(int id);

}
