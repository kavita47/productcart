package com.capgemini.Exception;

public class InvalidId extends RuntimeException {

}
