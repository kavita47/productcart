package com.capgemini.Exception;

public class EmptyProductList extends RuntimeException{

}
