package com.capgemini.Exception;

public class InvalidProductException extends RuntimeException {

}
