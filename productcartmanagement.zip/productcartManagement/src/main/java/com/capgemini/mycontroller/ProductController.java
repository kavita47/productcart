package com.capgemini.mycontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.Exception.EmptyProductList;
import com.capgemini.Exception.InvalidId;
import com.capgemini.Exception.InvalidProductException;
import com.capgemini.bean.Product;
import com.capgemini.service.IProductService;




@RestController
public class ProductController {
	@Autowired
	IProductService service;
	@RequestMapping(value="/addProduct",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product product){
		product=service.addProduct(product);
		return product;
			
			
		}
	@RequestMapping(value="/getProduct/{id}",produces="application/json")
	public Product findProduct(@PathVariable int id) {
	      Product product=service.findProduct(id);
		return product;
		
	}
	@RequestMapping(value="/updateProduct",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Product updateProduct(@RequestBody Product product) {
		product=service.updateProduct(product);
		return product;
		
		
	}
	@RequestMapping(value="/deleteProduct/{id}",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Product deleteProduct(@PathVariable int id) {
		Product product=service.removeProduct(id);
		return product;
		
		
	}
	@RequestMapping(value="/getProductList",produces="application/json")
	public List<Product>getCustomerList(){
		List<Product> list = service.getProductList();
		return list;
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Product Id not present")
	@ExceptionHandler({InvalidId.class})
	public void handleIdException()
	{
		
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Deleted product Id not present")
	@ExceptionHandler({InvalidProductException.class})
	public void handleProductException()
	{
		
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Product List is empty")
	@ExceptionHandler({EmptyProductList.class})
	public void handleEmptyException()
	{
		
	}
}
